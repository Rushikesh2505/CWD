package com.smart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartcontactmanagerCwd6Application {

	public static void main(String[] args) {
		SpringApplication.run(SmartcontactmanagerCwd6Application.class, args);
	}
//this is comment
}
